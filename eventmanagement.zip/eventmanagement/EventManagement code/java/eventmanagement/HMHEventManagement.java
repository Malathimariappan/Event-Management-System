package eventmanagement;
import java.sql.*;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class HMHEventManagement {
    private static final String URL = "jdbc:mysql://localhost:3306/hmh_event_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Harini9361."; 

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Database Connected Successfully!");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public static boolean isEmailExists(String email) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM hmh_event WHERE email = ?")) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
      
        	e.printStackTrace();
        }
        return false;
    }

    public static void addUser(String name, String email, String password,String uname,String date,double price,String pname,double pprice,int userId, int productId, int quantity) {
        if (isEmailExists(email)) {
            System.out.println("Error: Email already exists!");
            return;
        }

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO hmh_event (record_type, user_name, email, password,event_name, event_date, event_price,product_name, product_price, user_id, product_id, quantity) VALUES ('User',?,?,?, ?, ?,?,?, ?,?,?,?)")) {
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, uname);
            ps.setString(5, date);
            ps.setDouble(6, price);
            ps.setString(7, pname);
            ps.setDouble(8, pprice);
            ps.setInt(9, userId);
            ps.setInt(10, productId);
            ps.setInt(11, quantity);
            ps.executeUpdate();// Storing password as plain text
            System.out.println("User Added Successfully!");
            System.out.println("Event Added Successfully!");
            System.out.println("Product Added Successfully!");
            System.out.println("Cart Added Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void getUsers() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, user_name, email FROM hmh_event WHERE record_type = 'User'")) {
            System.out.println("\nUsers List:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("user_name") + " | " + rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteUser(int userId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM hmh_event WHERE id = ? AND record_type = 'User'");) {
            ps.setInt(1, userId);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User Deleted Successfully!");
            } else {
                System.out.println("User Not Found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void getEvents() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, event_name, event_date, event_price FROM hmh_event WHERE record_type = 'Event'")) {
            System.out.println("\nEvents List:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("event_name") + " | " + rs.getString("event_date") + " | ₹" + rs.getDouble("event_price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteEvent(int eventId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM hmh_event WHERE id = ? AND record_type = 'Event'");) {
            ps.setInt(1, eventId);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Event Deleted Successfully!");
            } else {
                System.out.println("Event Not Found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void getProducts() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT id, product_name, product_price FROM hmh_event WHERE record_type = 'Product'")) {
            System.out.println("\nProduct List:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("product_name") + " | ₹" + rs.getDouble("product_price"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteProduct(int productId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM hmh_event WHERE id = ? AND record_type = 'Product'");) {
            ps.setInt(1, productId);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Product Deleted Successfully!");
            } else {
                System.out.println("Product Not Found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void deleteCartItem(int cartId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement("DELETE FROM hmh_event WHERE id = ? AND record_type = 'Cart'");) {
            ps.setInt(1, cartId);
            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Cart Item Deleted Successfully!");
            } else {
                System.out.println("Cart Item Not Found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void getCartItems(int userId) {
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT id, product_name, product_price, quantity FROM hmh_event WHERE record_type = 'Cart' AND user_id = ?")) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            System.out.println("\nCart Items:");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " + rs.getString("product_name") + " | ₹" + rs.getDouble("product_price") + " | Qty: " + rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n===== HMH Event Management System =====");
            System.out.println("1. Add User");
            System.out.println("2. View Users");
            System.out.println("3. Delete User");
            System.out.println("4. View Events");
            System.out.println("5. Delete Event");
            System.out.println("6. View Products");
            System.out.println("7. Delete Product");
            System.out.println("8. View Cart");
            System.out.println("9. Delete Cart Item");
            System.out.println("10. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // to consume the newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter Password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter Event Name: ");
                    String eventName = scanner.nextLine();
                    System.out.print("Enter Event Date (YYYY-MM-DD): ");
                    String eventDate = scanner.nextLine();
                    System.out.print("Enter Price: ");
                    double eventPrice = scanner.nextDouble();
                    System.out.print("Enter Product Name: ");
                    scanner.nextLine(); // Consume the leftover newline character
                    String productName = scanner.nextLine();
                    System.out.print("Enter Price: ");
                    double productPrice = scanner.nextDouble();
                    System.out.print("Enter User ID: ");
                    int user_id = scanner.nextInt();
                    System.out.print("Enter Product ID: ");
                    int product_id = scanner.nextInt();
                    System.out.print("Enter Quantity: ");
                    int quantity = scanner.nextInt();
                    addUser(name, email, password,eventName,eventDate,eventPrice,productName,productPrice,user_id,product_id,quantity);
                    break;
                case 2:
                    getUsers();
                    break;
                case 3:
                    System.out.print("Enter User ID: ");
                    int userId = scanner.nextInt();
                    deleteUser(userId);
                    break;
                case 4:
                    getEvents();
                    break;
                case 5:
                    System.out.print("Enter Event ID: ");
                    int eventId = scanner.nextInt();
                    deleteEvent(eventId);
                    break;
                case 6:
                    getProducts();
                    break;
                case 7:
                    System.out.print("Enter Product ID: ");
                    int productId = scanner.nextInt();
                    deleteProduct(productId);
                    break;
                case 8:
                    System.out.print("Enter User ID: ");
                    int cartUserId = scanner.nextInt();
                    getCartItems(cartUserId);
                    break;
                case 9:
                    System.out.print("Enter Cart Item ID: ");
                    int cartId = scanner.nextInt();
                    deleteCartItem(cartId);
                    break;
                case 10:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }
        } while (choice != 11);

        scanner.close();
    }
}
